import unittest
import main

class TestMain(unittest.TestCase):
    #write the code to test

  def test_do_stuff_with_integer(self):
    test_param = 10
    result = main.do_stuff(test_param)
    self.assertEqual(result, 15)

  def test_do_stuff_with_string(self):
    test_param = 'my name is Idan'
    result = main.do_stuff(test_param)
    self.assertIsInstance(result, ValueError)
    # We wantto return only True.

  def test_do_stuff(self):
    test_param = None
    result = main.do_stuff(test_param)
    self.assertEqual(result, 'please enter a number')


unittest.main()

# u can run a single or multiple tests by using unittest.main()