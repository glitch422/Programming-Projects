<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $first_name = $_POST["first_name"];
    $last_name = $_POST["last_name"];
    $birthday = $_POST["birthday"];
    $gender = $_POST["gender"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $country = $_POST["country"];

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email format");
    }

    // Validate password
    if (strlen($password) < 12) {
        die("Password must be at least 12 characters");
    }

    // Hash the password using SHA1
    $hashed_password = sha1($password);

    // Retrieve selected pets
    $selected_pets = [];
    if (isset($_POST['pet1'])) {
        $selected_pets[] = $_POST['pet1'];
    }
    if (isset($_POST['pet2'])) {
        $selected_pets[] = $_POST['pet2'];
    }
    if (isset($_POST['pet3'])) {
        $selected_pets[] = $_POST['pet3'];
    }

    // Perform registration logic (e.g., save to a database)
    // For demonstration purposes, let's echo the received data and the hashed password
    echo "First Name: $first_name<br>";
    echo "Last Name: $last_name<br>";
    echo "Birthday: $birthday<br>";
    echo "Gender: $gender<br>";
    echo "Email: $email<br>";
    // For security, don't echo or store passwords directly
    echo "Hashed Password: $hashed_password<br>";
    echo "Country: $country<br>";

    // Display selected pets
    echo "Selected Pets: ";
    if (empty($selected_pets)) {
        echo "None";
    } else {
        echo implode(', ', $selected_pets);
    }
}
?>
